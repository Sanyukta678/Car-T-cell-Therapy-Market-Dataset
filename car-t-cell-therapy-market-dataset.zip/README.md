# CAR-T Cell Therapy Market — Dataset

This dataset contains structured metadata and summaries derived from the public landing page of the CAR-T Cell Therapy Market report (HC3563) by Next Move Strategy Consulting.

Includes:
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- table_of_contents.md
- license.txt

Only publicly available information is included — no paid report content.
